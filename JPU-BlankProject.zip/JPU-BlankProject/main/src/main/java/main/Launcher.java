
package main;

import view.FrameMenu;

public class Launcher
{
	/**
	 * Just run the frame menu.
	 * 
	 * @param args
	 */
	public static void main(String[] args)
	{
		FrameMenu.runFrameMenu();
	}
}

package controller.access;

import controller.LaunchGame;

public class GameAcccess {
	public static void launch()
	{
		LaunchGame.runGameThread();
	}
}

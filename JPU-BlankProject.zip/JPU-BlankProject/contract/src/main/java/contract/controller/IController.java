package contract.controller;

public interface IController {

}

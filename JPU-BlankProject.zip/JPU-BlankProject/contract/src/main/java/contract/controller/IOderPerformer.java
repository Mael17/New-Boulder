package contract.controller;

public interface IOderPerformer {
	 void orderPerform(final IUserOrder userOrder);

	}


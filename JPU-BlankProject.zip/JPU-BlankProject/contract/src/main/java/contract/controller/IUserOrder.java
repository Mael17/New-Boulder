package contract.controller;

public interface IUserOrder {
	 Order getOrder();
}

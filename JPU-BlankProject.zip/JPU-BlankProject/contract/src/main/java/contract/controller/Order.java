package contract.controller;

public enum Order {
	UP,
    LEFT,
    DOWN,
    RIGHT,
    EXIT
}

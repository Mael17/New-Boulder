package contract.view;

import java.awt.event.KeyEvent;

public interface IEventPerformer {
	 void eventPerform(KeyEvent keyEvent);
}

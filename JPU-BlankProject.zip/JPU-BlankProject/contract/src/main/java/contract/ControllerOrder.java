package contract;

public enum ControllerOrder {
	/** The English. */
	English ,
	/** The French. */
	Francais,
	/** The Deutch. */
	Deutsch,
	/** The Indonesia. */
	Indonesia
}

package contract.model;

public interface IBreakable {

}

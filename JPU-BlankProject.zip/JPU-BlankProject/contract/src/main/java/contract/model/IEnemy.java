package contract.model;

public interface IEnemy {

}

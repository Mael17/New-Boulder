package contract.model;

public enum Direction {
	UP,
    RIGHT,
    DOWN,
    LEFT;
}

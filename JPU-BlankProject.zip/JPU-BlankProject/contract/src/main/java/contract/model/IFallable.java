package contract.model;

public interface IFallable {

}

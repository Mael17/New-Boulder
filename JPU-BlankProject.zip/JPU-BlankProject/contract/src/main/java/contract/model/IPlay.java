package contract.model;

public interface IPlay {

}

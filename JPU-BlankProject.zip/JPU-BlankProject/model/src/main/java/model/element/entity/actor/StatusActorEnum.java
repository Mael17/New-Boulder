package model.element.entity.actor;

public enum StatusActorEnum {
	EXPLODING, MOVINGUP, MOVINGDOWN, MOVINGRIGHT, MOVINGLEFT, IDLE, DEAD,
}

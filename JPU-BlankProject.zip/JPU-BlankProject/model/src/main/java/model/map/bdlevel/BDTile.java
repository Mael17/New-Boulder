package model.map.bdlevel;

public enum BDTile {
	 EMPTY              , 
     DIRT               ,
     TITANIUM           , 
     WALL               , 
     ROCK               , 
     FALLINGROCK        , 
     DIAMOND            , 
     FALLINGDIAMOND     , 
     AMOEBA             , 
     FIREFLY            , 
     BUTTERFLY          , 
     EXIT               , 
     PLAYER             
}